from pyrogram.types import  KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram import emoji

btn_info = KeyboardButton(f'{emoji.CHRISTMAS_TREE} Инфо')
btn_santa = KeyboardButton(f'{emoji.SANTA_CLAUS} Санта')
btn_gif = KeyboardButton(f'{emoji.VIDEO_CAMERA} Гифка')

kb_main = ReplyKeyboardMarkup(
    keyboard=[
        [btn_info, btn_santa],
        [btn_gif]
    ],
    resize_keyboard=True
)