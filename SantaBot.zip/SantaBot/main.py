from pyrogram import Client, filters
from datetime import datetime
import config
import keyboards
from keyboards import kb_main

# Создаем объект бота
bot = Client(
    "@SantaSFG_bot",
    api_id=config.API_ID,
    api_hash=config.API_HASH,
    bot_token=config.BOT_TOKEN
)

# Фильтр для кнопки (если понадобится)
def button_filter(button):
    async def func(_, __, msg):
        return msg.text == button.text
    return filters.create(func, "ButtonFilter", button=button)

# Команда /start
@bot.on_message(filters.command("start"))
async def start(bot, message):
    await bot.send_sticker(
        message.chat.id,
        "CAACAgIAAxkBAAENTRpnV41aKRbx2cTuaX2erEejgrFY4wACdxIAAscpaUj6aDiZM6SA4jYE",
                                                            reply_markup=kb_main
    )

# Команда /Santa
@bot.on_message(filters.command("Santa")  | button_filter(keyboards.btn_santa))
async def santa(bot, message):
    await bot.send_photo(
        message.chat.id,
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUtGs0TMaPQCudyYIa9t_94F4zWTf2MOKayg&s"
    )

# Команда /day
@bot.on_message(filters.command("day") | button_filter(keyboards.btn_info))
async def day(bot, message):
    now = datetime.now()  # Текущая дата
    next_new_year = datetime(year=now.year + 1, month=1, day=1)  # Следующий Новый год
    days_left = (next_new_year - now).days  # Разница в днях
    await bot.send_message(
        message.chat.id,
        f"До Нового года осталось {days_left} дней! 🎉"
    )

# Команда /gif

@bot.on_message(filters.command("creator")| button_filter(keyboards.btn_gif))
async def creator(bot, message):
    await bot.send_message(
        message.chat.id,
        "Создатель: SteelFoxGames!"
    )
@bot.on_message(filters.command("gif")| button_filter(keyboards.btn_gif))
async def gif(bot, message):
    await bot.send_video(
        message.chat.id,
        "https://i.pinimg.com/originals/5d/37/f3/5d37f3d56e596ef1cbc2ea1967bf72a2.gif"
    )

# Запуск бота
bot.run()
